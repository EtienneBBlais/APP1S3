package ingredients;

public class Fruit extends Ingredient{
    public Fruit() {
        setTypeIngredient(TypeIngredient.FRUIT);
    }
}
