package ingredients;

public class Viande extends Ingredient{
    public Viande() {
        setTypeIngredient(TypeIngredient.VIANDE);
    }
}
