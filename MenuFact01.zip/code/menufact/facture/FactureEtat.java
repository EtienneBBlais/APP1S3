package menufact.facture;

public enum FactureEtat {
    OUVERTE, FERMEE, PAYEE
}
